package com.example.reflexgames;

import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnTouch;


public class MainActivity extends AppCompatActivity {

    public static final int BG_COLOR = Color.parseColor("#E8EAF6");
    public static final long MIN_DELAY = 1000; // 1 sec
    public static final long MAX_DELAY = 5000; // 5 sec
    public static final int NB_TRIES = 5; // 5 tries
    public int currentTry = 1;
    @BindView(R.id.root)
    View root;
    @BindView(R.id.TouchArea)
    View TouchArea;
    @BindView(R.id.targetIu)
    View targetIu;
    @BindView(R.id.msgTv)
    TextView msgTv;
    private boolean gameStarted, displayed;
    private long totalTime, startTime, bestTime, averageTime;
    private static Handler HANDLER;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ButterKnife.bind(this);
        HANDLER = new Handler();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (HANDLER != null)
        {
            HANDLER.removeCallbacksAndMessages(null);
        }
    }

    @OnTouch(R.id.root)
    public boolean manageGame(){
        if(gameStarted)
        {
            if (displayed)
            {
                long delay = System.currentTimeMillis() - startTime;

                if (delay < bestTime)
                {
                    bestTime = delay;
                }

                totalTime += delay;
                msgTv.setText(getString(R.string.ok_in).replace("#delay#",delay + ""));
                root.setBackgroundColor(BG_COLOR);
                TouchArea.setVisibility(View.GONE);
                targetIu.setVisibility(View.GONE);
                currentTry++;

                if (currentTry > NB_TRIES)
                {
                    averageTime = totalTime / NB_TRIES;
                    gameStarted = false;
                    msgTv.setText(getString(R.string.game_ended).
                            replace("#averageTime#", averageTime + "").
                            replace("#bestTime#", bestTime + "")
                    );
                }
                else
                {
                    displayed = false;
                    HANDLER.postDelayed(bgColorTask, randomLongBetween(MIN_DELAY,MAX_DELAY));
                }
            }
            else
            {
                HANDLER.removeCallbacks(bgColorTask);
                gameStarted = false;
                msgTv.setText(R.string.you_lose);
            }
        }
        else
        {
            gameStarted = true;
            displayed = false;
            bestTime = Long.MAX_VALUE;
            totalTime = 0;
            currentTry = 1;
            msgTv.setText(R.string.be_ready);
            HANDLER.postDelayed(bgColorTask, randomLongBetween(MIN_DELAY, MAX_DELAY));
        }
        return false;
    }

    private Runnable bgColorTask = new Runnable() {
        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    msgTv.setText("");
                    root.setBackgroundColor(Color.RED);
                    TouchArea.setVisibility(View.VISIBLE);
                    targetIu.setVisibility(View.VISIBLE);
                    displayed = true;
                    startTime = System.currentTimeMillis();
                }
            });
        }
    };

    public static long randomLongBetween(long origin, long bound){
        return origin + (long) (Math.random() * (bound - origin));
    }
}